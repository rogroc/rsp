document.getElementById('changeContent').addEventListener('click', function() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    chrome.tabs.executeScript(tabs[0].id, { code: "console.log('PROVA'); var allElements = document.querySelectorAll('*'); allElements.forEach(function(element) { element.style.display = 'block'; });" });
  });
});
