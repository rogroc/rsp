document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('openUrlButton').addEventListener('click', function() {
    var newUrl = 'https://www.boe.es/borme/dias/2023/11/02/'; // Reemplaça amb la teva nova URL

    chrome.tabs.create({ url: newUrl, active: false }, function(tab) {
      // Callback que s'executarà quan es crea la nova pestanya
      chrome.tabs.executeScript(tab.id, { file: 'contentScript.js' });
    });
  });
});
