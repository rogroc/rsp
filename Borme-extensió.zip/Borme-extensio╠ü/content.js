chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.date) {
    var url = "https://www.google.com";
    window.open(url, "_blank");
  }
});
