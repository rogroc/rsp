// background.js
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    if (request.action === "fetchPdf") {
      fetch(request.url, {
        mode: 'cors', // Necessari per a les peticions CORS
        headers: {
          'Access-Control-Allow-Origin': '*'
        }
      })
      .then(response => response.blob())
      .then(blob => sendResponse({ success: true, data: blob }))
      .catch(error => sendResponse({ success: false, error: error.message }));
      return true;  // Permet la gestió asíncrona de la resposta
    }
  }
);
